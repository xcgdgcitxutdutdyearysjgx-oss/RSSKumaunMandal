# Run in PowerShell with JDK installed.
$keytool = "keytool"
& $keytool -genkeypair -v -keystore rsskumaun-upload.jks -alias rsskumaun_upload -keyalg RSA -keysize 4096 -validity 10000 -storetype PKCS12 -dname "CN=RSSKumaunMandal, OU=App, O=RSSKumaunMandal, L=Almora, ST=Uttarakhand, C=IN"
