/* RSSKumaunMandal - Firebase-powered content shell.
   Put Firebase config in firebase-config.js. For production, use Firebase Authentication
   for admin accounts; the sample credentials below are only a UI bootstrap and should
   be replaced before public release. */
let db=null, storage=null, auth=null, firebaseReady=false;
const gradients=['linear-gradient(135deg,#2563eb,#06b6d4)','linear-gradient(135deg,#7c3aed,#ec4899)','linear-gradient(135deg,#059669,#14b8a6)','linear-gradient(135deg,#ea580c,#f59e0b)','linear-gradient(135deg,#db2777,#8b5cf6)','linear-gradient(135deg,#0891b2,#2563eb)'];
let data={settings:{title:'RSSKumaunMandal',subtitle:'राजकीय शिक्षक संघ',logoText:'PK'},actions:[
['शासनादेश (निदेशालय)','📜'],['शासनादेश (अपर निदेशक कार्यालय)','🏛️'],['खबर','📰'],['अनापत्ति पत्र','📄'],['सेवा संयोजन','🔗'],['शैक्षिक अभिवृद्धि','🎓'],['चयन प्रोन्नत वेतनमान','📈'],['उपनाम परिवर्तन','✏️'],['सत्रांत लाभ','📚'],['गोपनीय आख्या / प्रतिकूल प्रविष्टि','🔐']],leaders:[],news:[],slider:[]};
async function initFirebase(){
 if(!window.FIREBASE_CONFIG||window.FIREBASE_CONFIG.apiKey==='YOUR_API_KEY') return;
 try{
  const {initializeApp}=await import('https://www.gstatic.com/firebasejs/12.2.1/firebase-app.js');
  const {getDatabase,ref,get,set,onValue,push,remove}=await import('https://www.gstatic.com/firebasejs/12.2.1/firebase-database.js');
  const {getStorage,ref:sr,uploadBytes,getDownloadURL,deleteObject}=await import('https://www.gstatic.com/firebasejs/12.2.1/firebase-storage.js');
  const {getAuth,signInWithEmailAndPassword}=await import('https://www.gstatic.com/firebasejs/12.2.1/firebase-auth.js');
  window.FB={ref,get,set,onValue,push,remove,sr,uploadBytes,getDownloadURL,deleteObject,signInWithEmailAndPassword};
  const app=initializeApp(window.FIREBASE_CONFIG); db=getDatabase(app); storage=getStorage(app); auth=getAuth(app); firebaseReady=true;
  onValue(ref(db,'site'),snap=>{if(snap.exists()){data={...data,...snap.val()};renderAll();}});
 }catch(e){console.warn('Firebase unavailable',e)}
}
function toggleNav(){document.getElementById('nav').classList.toggle('open')}
function openModal(html){document.getElementById('modalContent').innerHTML=html;document.getElementById('modal').classList.remove('hidden')}
function closeModal(){document.getElementById('modal').classList.add('hidden')}
function renderAll(){
 document.getElementById('siteTitle').textContent=data.settings?.title||'RSSKumaunMandal';document.getElementById('siteSub').textContent=data.settings?.subtitle||'राजकीय शिक्षक संघ';document.getElementById('logo').textContent=data.settings?.logoText||'PK';
 const actions=document.getElementById('actions');actions.innerHTML='';(data.actions||[]).forEach((a,i)=>{const [title,icon]=Array.isArray(a)?a:[a.title,a.icon||'📁'];let b=document.createElement('button');b.className='action';b.style.background=gradients[i%gradients.length];b.innerHTML=`<span class="ico">${icon}</span><b>${title}</b><small>सभी सामग्री देखें →</small>`;b.onclick=()=>openCategory(i,title);actions.appendChild(b)});
 const leaders=document.getElementById('leadersGrid');leaders.innerHTML=(data.leaders||[]).map(x=>`<article class="leader"><img class="avatar" src="${x.photo||''}" onerror="this.style.visibility='hidden'"><h3>${x.name||'नाम'}</h3><div class="muted">${x.designation||''} · ${x.district||''}</div><p>${x.description||''}</p></article>`).join('')||'<p class="muted">Leadership profiles admin panel से जोड़े जा सकते हैं।</p>';
 const news=document.getElementById('newsGrid');news.innerHTML=(data.news||[]).map(x=>`<article class="news">${x.image?`<img src="${x.image}">`:''}<div class="body"><h3>${x.title||''}</h3><p>${x.description||''}</p>${x.link?`<button class="read" onclick="location.href='${x.link}'">Read More</button>`:''}</div></article>`).join('')||'<p class="muted">अभी कोई news नहीं है।</p>';
 renderSlider();
}
let slideIndex=0,sliderTimer;
function renderSlider(){const s=document.getElementById('slider');const imgs=data.slider||[];if(!imgs.length){s.innerHTML='<div class="slide active"><div><h2>राजकीय शिक्षक संघ</h2><p>Admin panel से unlimited slider images जोड़ें।</p></div></div>';document.getElementById('dots').innerHTML='';return} s.innerHTML=imgs.map((x,i)=>`<div class="slide ${i===0?'active':''}" style="background-image:linear-gradient(90deg,#0009,#0001),url('${x.url||x}')"><div><h2>${x.title||'RSSKumaunMandal'}</h2><p>${x.description||''}</p></div></div>`).join('');document.getElementById('dots').innerHTML=imgs.map((_,i)=>`<span class="dot ${i===0?'on':''}" onclick="showSlide(${i})"></span>`).join('');slideIndex=0;clearInterval(sliderTimer);sliderTimer=setInterval(()=>nextSlide(),5000)}
function showSlide(n){const slides=[...document.querySelectorAll('.slide')],dots=[...document.querySelectorAll('.dot')];if(!slides.length)return;slideIndex=(n+slides.length)%slides.length;slides.forEach((x,i)=>x.classList.toggle('active',i===slideIndex));dots.forEach((x,i)=>x.classList.toggle('on',i===slideIndex))}
function nextSlide(){showSlide(slideIndex+1)}function prevSlide(){showSlide(slideIndex-1)}
function openCategory(i,title){let c=(data.categories&&data.categories[i])||{};let items=c.items||[];openModal(`<h2>${title}</h2><input class="search" placeholder="Search PDFs, notices, documents..." oninput="filterItems(this.value)"><div id="catItems">${items.map(item=>itemCard(item)).join('')||'<p class="muted">इस category में अभी सामग्री नहीं है।</p>'}</div>`)}
function itemCard(x){let t=x.type||'file';let url=x.url||'#';return `<div class="adminRow catItem" data-text="${(x.title||'').toLowerCase()}"><b>${x.title||'Untitled'}</b><div class="muted">${x.description||''}</div><button class="read" onclick="window.open('${url}','_blank')">${t==='link'?'Open Link':'View / Download'}</button></div>`}
function filterItems(q){document.querySelectorAll('.catItem').forEach(x=>x.style.display=x.dataset.text.includes(q.toLowerCase())?'block':'none')}
function openOrg(kind){openModal(`<h2>${kind==='creative'?'शिक्षक मंडल':'राजकीय शिक्षक संघ'}</h2><p>इस संगठन का अलग content page यहाँ उपलब्ध कराया जा सकता है। Admin panel से content manage करें।</p>`)}
function openAdminLogin(){openModal(`<div class="login"><h2>Admin Login</h2><p class="muted">Production में Firebase Authentication इस्तेमाल करें।</p><input id="u" placeholder="Username"><input id="p" type="password" placeholder="Password"><button class="primary" onclick="loginAdmin()">Login</button></div>`)}
async function loginAdmin(){const u=document.getElementById('u').value,p=document.getElementById('p').value;if(u==='Rsskumaunmandal'&&p==='Rss@2026'){openAdmin()}else alert('Invalid login')}
function openAdmin(){openModal(`<div class="admin"><h2>Admin Dashboard</h2><p class="muted">यहाँ homepage का content manage करें। Firebase config जोड़ने पर changes database में save किए जा सकते हैं।</p><div class="adminRow"><b>Website</b><input id="aTitle" value="${data.settings?.title||''}"><input id="aSub" value="${data.settings?.subtitle||''}"><button class="primary" onclick="saveSettings()">Save</button></div><div class="adminRow"><b>Action Buttons</b>${(data.actions||[]).map((a,i)=>{let title=Array.isArray(a)?a[0]:a.title;let icon=Array.isArray(a)?a[1]:a.icon;return `<div><input id="at${i}" value="${title}"><input id="ai${i}" value="${icon||'📁'}"><button onclick="saveAction(${i})">Save</button></div>`}).join('')}</div><div class="adminRow"><b>Add news</b><input id="nt" placeholder="Title"><textarea id="nd" placeholder="Description"></textarea><input id="nl" placeholder="Read More link"><button class="primary" onclick="addNews()">Add News</button></div><div class="adminRow"><b>Slider</b><input type="file" id="sliderFiles" accept="image/*" multiple><button class="primary" onclick="uploadSlider()">Upload Images</button></div><div class="adminRow"><b>Security</b><p class="muted">Public release से पहले Firebase Authentication + Storage Rules लगाना जरूरी है। Client-side password को production secret न मानें।</p></div></div>`)}
async function dbSet(path,val){if(!firebaseReady){alert('Firebase config अभी सेट नहीं है।');return}await FB.set(FB.ref(db,path),val);alert('Saved')}
async function saveSettings(){data.settings={...data.settings,title:document.getElementById('aTitle').value,subtitle:document.getElementById('aSub').value};await dbSet('site/settings',data.settings);renderAll()}
async function saveAction(i){let a=data.actions[i];if(Array.isArray(a))a=[document.getElementById('at'+i).value,document.getElementById('ai'+i).value];else a={...a,title:document.getElementById('at'+i).value,icon:document.getElementById('ai'+i).value};data.actions[i]=a;await dbSet('site/actions',data.actions);renderAll()}
async function addNews(){let n={title:document.getElementById('nt').value,description:document.getElementById('nd').value,link:document.getElementById('nl').value,createdAt:Date.now()};data.news=[n,...(data.news||[])];await dbSet('site/news',data.news);renderAll()}
async function uploadSlider(){if(!firebaseReady){alert('Firebase config अभी सेट नहीं है।');return}let files=document.getElementById('sliderFiles').files;if(!files.length)return;for(const f of files){let path='slider/'+Date.now()+'_'+f.name;let r=FB.sr(storage,path);await FB.uploadBytes(r,f);let url=await FB.getDownloadURL(r);data.slider.push({url,title:'',description:''})}await dbSet('site/slider',data.slider);renderAll();alert('Images uploaded')}
initFirebase();renderAll();
