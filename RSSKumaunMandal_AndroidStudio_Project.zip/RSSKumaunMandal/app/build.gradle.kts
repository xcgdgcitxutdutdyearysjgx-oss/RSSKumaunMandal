plugins { id("com.android.application") }

android {
    namespace = "com.priyanshu.pk"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.priyanshu.pk"
        minSdk = 23
        targetSdk = 36
        versionCode = 230000
        versionName = "23.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
        debug { isMinifyEnabled = false }
    }

    buildFeatures { buildConfig = true }
}

dependencies {
    implementation("androidx.core:core:1.17.0")
    implementation("androidx.appcompat:appcompat:1.7.1")
    implementation("com.google.android.material:material:1.13.0")
    implementation("androidx.webkit:webkit:1.14.0")
    implementation("com.android.billingclient:billing:8.0.0")
}
