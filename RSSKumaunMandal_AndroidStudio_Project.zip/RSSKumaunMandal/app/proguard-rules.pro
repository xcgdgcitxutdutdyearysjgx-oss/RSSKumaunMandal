# Keep WebView bridge methods.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
